import tkinter as tk
from tkinter import messagebox
import os
import shutil

# === FIND USER HOME AUTOMATICALLY ===
user_home = os.path.expanduser("~")

folders_to_organise = [
    os.path.join(user_home, "Downloads"),
    os.path.join(user_home, "Documents")
]

# === PROGRESS POPUP ===
def show_progress_popup(text):
    popup = tk.Toplevel()
    popup.title("Please wait")
    popup.geometry("250x80")
    popup.resizable(False, False)

    label = tk.Label(popup, text=text)
    label.pack(pady=20)

    popup.update()
    return popup


# === ORGANISE FILES ===
def organise_files():
    try:
        progress_popup = show_progress_popup("Organising files...")

        for folder_path in folders_to_organise:

            if not os.path.exists(folder_path):
                continue

            for filename in os.listdir(folder_path):

                file_path = os.path.join(folder_path, filename)

                # skip folders
                if os.path.isdir(file_path):
                    continue

                # ignore hidden/system files
                if filename.startswith("."):
                    continue

                # get file extension
                extension = os.path.splitext(filename)[1][1:].upper()

                if extension == "":
                    extension = "NO_EXTENSION"

                new_folder = os.path.join(folder_path, extension)

                os.makedirs(new_folder, exist_ok=True)

                new_file_path = os.path.join(new_folder, filename)

                counter = 1
                while os.path.exists(new_file_path):
                    name, ext = os.path.splitext(filename)
                    new_file_path = os.path.join(new_folder, f"{name}_{counter}{ext}")
                    counter += 1

                shutil.move(file_path, new_file_path)

        progress_popup.destroy()
        messagebox.showinfo("Success", "Files organised successfully!")

    except Exception as e:
        progress_popup.destroy()
        messagebox.showerror("Error", f"An error occurred:\n{e}")


# === RESET FILES ===
def reset_files():
    try:
        progress_popup = show_progress_popup("Resetting files...")

        for folder_path in folders_to_organise:

            if not os.path.exists(folder_path):
                continue

            for folder in os.listdir(folder_path):

                folder_full = os.path.join(folder_path, folder)

                # ONLY target organiser folders
                if os.path.isdir(folder_full) and folder.isupper() and 3 <= len(folder) <= 4 and folder != "SRC":

                    for file in os.listdir(folder_full):

                        file_path = os.path.join(folder_full, file)

                        new_file_path = os.path.join(folder_path, file)

                        counter = 1
                        while os.path.exists(new_file_path):
                            name, ext = os.path.splitext(file)
                            new_file_path = os.path.join(folder_path, f"{name}_{counter}{ext}")
                            counter += 1

                        shutil.move(file_path, new_file_path)

        progress_popup.destroy()
        messagebox.showinfo("Reset Complete", "Files moved back successfully!")

    except Exception as e:
        progress_popup.destroy()
        messagebox.showerror("Error", f"An error occurred during reset:\n{e}")


# === GUI WINDOW ===
window = tk.Tk()
window.title("LichtOrganiser 1.0.0")
window.geometry("320x180")

label = tk.Label(
    window,
    text="Organise Downloads and Documents by file type",
    wraplength=260
)
label.pack(pady=10)

organise_button = tk.Button(window, text="Organise Files", command=organise_files)
organise_button.pack(pady=5)

reset_button = tk.Button(window, text="Reset Organisation", command=reset_files)
reset_button.pack(pady=5)

exit_button = tk.Button(window, text="Exit", command=window.quit)
exit_button.pack(pady=5)

window.mainloop()

