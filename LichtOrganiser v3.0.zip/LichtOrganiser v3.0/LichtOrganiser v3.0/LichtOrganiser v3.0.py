import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import os
import shutil
import threading
import time
from datetime import datetime, timedelta
import platform
try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
    DND_AVAILABLE = True
except ImportError:
    DND_AVAILABLE = False

# === GLOBALS ===
selected_items = []
target_directory = None
moved_files = []
dark_mode = False
schedule_enabled = False
schedule_time = None

# === FUNCTIONS ===
def toggle_theme():
    global dark_mode
    dark_mode = not dark_mode
    apply_theme()

def choose_directory():
    global target_directory
    target_directory = filedialog.askdirectory()
    if target_directory:
        load_items_list()
        status_label.config(text=f"Target directory: {target_directory}")

def load_items_list():
    file_listbox.delete(0, tk.END)
    if target_directory:
        for root, dirs, files in os.walk(target_directory):
            for f in files:
                rel_path = os.path.relpath(os.path.join(root, f), target_directory)
                file_listbox.insert(tk.END, rel_path)

def select_all_items():
    file_listbox.select_set(0, tk.END)

def deselect_all_items():
    file_listbox.select_clear(0, tk.END)

def move_file(file_path, base_directory):
    if not os.path.isfile(file_path):
        return
    filename = os.path.basename(file_path)
    extension = os.path.splitext(filename)[1][1:].upper() or "NO_EXTENSION"
    new_folder = os.path.join(base_directory, extension)
    os.makedirs(new_folder, exist_ok=True)
    new_file_path = os.path.join(new_folder, filename)
    counter = 1
    while os.path.exists(new_file_path):
        name, ext = os.path.splitext(filename)
        new_file_path = os.path.join(new_folder, f"{name}_{counter}{ext}")
        counter += 1
    shutil.move(file_path, new_file_path)
    moved_files.append((file_path, new_file_path))
    status_label.config(text=f"Moved: {filename}")

def organise_worker(items_to_process):
    progress_bar['maximum'] = len(items_to_process)
    for idx, item in enumerate(items_to_process):
        item_path = os.path.join(target_directory, item)
        if os.path.isfile(item_path):
            move_file(item_path, target_directory)
        elif os.path.isdir(item_path):
            for root, dirs, files in os.walk(item_path):
                for f in files:
                    move_file(os.path.join(root, f), target_directory)
        progress_bar['value'] = idx + 1
        window.update_idletasks()
    status_label.config(text="Organisation complete!")
    messagebox.showinfo("Done", "Selected files/folders organised successfully!")

def organise_selected():
    global selected_items
    if not target_directory:
        messagebox.showwarning("No Directory", "Please choose a target directory first.")
        return
    selected_indices = file_listbox.curselection()
    if not selected_indices:
        messagebox.showwarning("No Selection", "No items selected. You can also use 'Organise All'.")
        return
    selected_items = [file_listbox.get(i) for i in selected_indices]
    if messagebox.askyesno("Confirm", f"Move {len(selected_items)} selected items? This can be undone."):
        threading.Thread(target=organise_worker, args=(selected_items,)).start()

def organise_all():
    if not target_directory:
        messagebox.showwarning("No Directory", "Please choose a target directory first.")
        return
    all_items = list(file_listbox.get(0, tk.END))
    if messagebox.askyesno("Confirm", f"Move all {len(all_items)} items including subfolder files? This can be undone."):
        threading.Thread(target=organise_worker, args=(all_items,)).start()

def reset_files():
    if not moved_files:
        messagebox.showinfo("Nothing to Undo", "No files have been moved yet.")
        return
    try:
        for original_path, moved_path in moved_files:
            if os.path.exists(moved_path):
                os.makedirs(os.path.dirname(original_path), exist_ok=True)
                shutil.move(moved_path, original_path)
        moved_files.clear()
        status_label.config(text="Reset complete!")
        messagebox.showinfo("Reset Complete", "Files moved back successfully!")
    except Exception as e:
        status_label.config(text="Error occurred")
        messagebox.showerror("Error", f"An error occurred during reset:\n{e}")

def apply_theme():
    bg = '#1E1E1E' if dark_mode else '#f5f5f5'
    fg = '#ffffff' if dark_mode else '#333333'
    window.configure(bg=bg)
    logo_label.configure(bg=bg, fg='#1E90FF')
    status_label.configure(bg=bg, fg="#4CAF50")
    schedule_indicator.configure(bg=bg)
    listbox_frame.configure(bg=bg)
    file_listbox.configure(bg='#2E2E2E' if dark_mode else 'white', fg='white' if dark_mode else 'black', selectbackground='#007ACC')
    btn_frame.configure(bg=bg)
    organise_btn_frame.configure(bg=bg)
    # Update buttons colors and hover
    for btn in hover_buttons:
        btn.configure(bg=bg if not dark_mode else '#2E2E2E', fg='white' if dark_mode else 'black')
        btn.bind("<Enter>", lambda e, b=btn: b.config(bg="#1E90FF", fg="white"))
        btn.bind("<Leave>", lambda e, b=btn: b.config(bg=bg if not dark_mode else '#2E2E2E', fg='white' if dark_mode else 'black'))

def show_how_to_use():
    tips_window = tk.Toplevel(window)
    tips_window.title("How to Use LichtManager")
    tips_window.geometry("400x300")
    tips_window.configure(bg="#1E1E1E" if dark_mode else "#f5f5f5")
    tips_text = (
        "1. Select a target directory.\n"
        "2. Preview files using 'Preview Before Organise'.\n"
        "3. Choose specific files/folders or organise all.\n"
        "4. Click 'Organise Selected' or 'Organise All'.\n"
        "5. Use 'Undo / Reset' to revert changes.\n"
        "6. Schedule Auto-Organise daily.\n"
        "7. Drag & drop folders/files onto the window.\n"
        "Enjoy a clean, organised folder!"
    )
    tips_label = tk.Label(tips_window, text=tips_text, justify="left",
                          bg="#1E1E1E" if dark_mode else "#f5f5f5",
                          fg="white" if dark_mode else "black", font=("Arial", 11))
    tips_label.pack(padx=10, pady=10)

# === Preview Before Organise ===
def preview_files():
    if not target_directory:
        messagebox.showwarning("No Directory", "Please choose a target directory first.")
        return
    preview_window = tk.Toplevel(window)
    preview_window.title("Preview Files")
    preview_window.geometry("500x400")
    preview_window.configure(bg="#1E1E1E" if dark_mode else "#f5f5f5")
    scrollbar = tk.Scrollbar(preview_window)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    listbox = tk.Listbox(preview_window, width=80, height=25, yscrollcommand=scrollbar.set,
                         bg="#2E2E2E" if dark_mode else "white", fg="white" if dark_mode else "black")
    listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    scrollbar.config(command=listbox.yview)
    # Populate all files including subfolders
    for f in file_listbox.get(0, tk.END):
        listbox.insert(tk.END, f)

# === SCHEDULED AUTO-ORGANISE ===
def schedule_organise():
    global schedule_enabled, schedule_time
    schedule_window = tk.Toplevel(window)
    schedule_window.title("Schedule Auto-Organise")
    schedule_window.geometry("300x150")
    tk.Label(schedule_window, text="Enter hour (0-23):").pack()
    hour_entry = tk.Entry(schedule_window)
    hour_entry.pack()
    tk.Label(schedule_window, text="Enter minute (0-59):").pack()
    minute_entry = tk.Entry(schedule_window)
    minute_entry.pack()
    def set_schedule():
        global schedule_enabled, schedule_time
        try:
            hour = int(hour_entry.get())
            minute = int(minute_entry.get())
            schedule_time = datetime.now().replace(hour=hour, minute=minute, second=0, microsecond=0)
            if schedule_time < datetime.now():
                schedule_time += timedelta(days=1)
            schedule_enabled = True
            messagebox.showinfo("Scheduled", f"Auto-Organise scheduled at {hour:02d}:{minute:02d} daily.")
            schedule_window.destroy()
        except:
            messagebox.showerror("Invalid Input", "Please enter valid hour and minute.")
    tk.Button(schedule_window, text="Set Schedule", command=set_schedule).pack(pady=10)

def check_schedule():
    global schedule_time
    if schedule_enabled and schedule_time:
        now = datetime.now()
        schedule_indicator.config(text=f"Next scheduled organise: {schedule_time.strftime('%H:%M')}", fg="#1E90FF")
        if now >= schedule_time and target_directory:
            organise_all()
            schedule_time += timedelta(days=1)
    else:
        schedule_indicator.config(text="Scheduled auto-organise: Off", fg="#B0B0B0")
    window.after(60000, check_schedule)

# === SPLASH SCREEN ===
def show_splash():
    splash = tk.Toplevel()
    splash.overrideredirect(True)
    splash_width, splash_height = 500, 300
    screen_w = splash.winfo_screenwidth()
    screen_h = splash.winfo_screenheight()
    x = (screen_w // 2) - (splash_width // 2)
    y = (screen_h // 2) - (splash_height // 2)
    splash.geometry(f"{splash_width}x{splash_height}+{x}+{y}")
    splash.configure(bg="#1E1E1E")
    tk.Label(splash, text="LichtManager 3.0", font=("Arial", 28, "bold"),
             fg="#1E90FF", bg="#1E1E1E").pack(pady=30)
    progress = ttk.Progressbar(splash, orient='horizontal', length=400, mode='determinate')
    progress.pack(pady=20)
    credit_label = tk.Label(splash, text="Created by Tekcraft\nSpecial thanks to h3llfire",
                            font=("Arial", 10), fg="#B0B0B0", bg="#1E1E1E")
    credit_label.pack(side="bottom", pady=10)
    tips = ["Preparing your folders...", "Almost ready...", "Optimising file organisation..."]
    tip_label = tk.Label(splash, text="", font=("Arial", 11), fg="white", bg="#1E1E1E")
    tip_label.pack(pady=5)
    for i in range(101):
        progress['value'] = i
        tip_label.config(text=tips[i % len(tips)])
        splash.update_idletasks()
        time.sleep(0.02)
    splash.destroy()

# === GUI SETUP ===
window = TkinterDnD.Tk() if DND_AVAILABLE else tk.Tk()
window.withdraw()  # hide main window until splash is done
window.title("LichtManager 3.0")
window.geometry("600x700")
window.resizable(True, True)

# Show splash first
show_splash()
window.deiconify()  # show main window after splash

# Logo
logo_label = tk.Label(window, text="LichtManager 3.0", font=("Arial", 28, "bold"), bg="#f5f5f5", fg="#1E90FF")
logo_label.pack(pady=15)

# Buttons
theme_btn = tk.Button(window, text="Toggle Dark/Light Mode", command=toggle_theme)
theme_btn.pack(pady=5)
choose_btn = tk.Button(window, text="Choose Target Directory", command=choose_directory)
choose_btn.pack(pady=5)
howto_btn = tk.Button(window, text="How to Use", command=show_how_to_use)
howto_btn.pack(pady=5)
preview_btn = tk.Button(window, text="Preview Before Organise", command=preview_files)
preview_btn.pack(pady=5)

# Listbox
listbox_frame = tk.Frame(window, bg="#f5f5f5")
listbox_frame.pack(pady=10)
file_listbox = tk.Listbox(listbox_frame, selectmode=tk.MULTIPLE, width=75, height=15, font=('Arial', 11))
file_listbox.pack()

# Select/Deselect
btn_frame = tk.Frame(window, bg="#f5f5f5")
btn_frame.pack(pady=5)
select_all_btn = tk.Button(btn_frame, text="Select All", command=select_all_items)
select_all_btn.pack(side=tk.LEFT, padx=5)
deselect_all_btn = tk.Button(btn_frame, text="Deselect All", command=deselect_all_items)
deselect_all_btn.pack(side=tk.LEFT, padx=5)

# Organise buttons and progress
organise_btn_frame = tk.Frame(window, bg="#f5f5f5")
organise_btn_frame.pack(pady=10)
progress_var = tk.IntVar()
progress_bar = ttk.Progressbar(organise_btn_frame, orient='horizontal', length=400, mode='determinate', variable=progress_var)
progress_bar.pack(pady=5)
organise_selected_btn = tk.Button(organise_btn_frame, text="Organise Selected", command=organise_selected)
organise_selected_btn.pack(side=tk.LEFT, padx=10)
organise_all_btn = tk.Button(organise_btn_frame, text="Organise All (Auto)", command=organise_all)
organise_all_btn.pack(side=tk.LEFT, padx=10)
reset_btn = tk.Button(organise_btn_frame, text="Undo / Reset", command=reset_files)
reset_btn.pack(side=tk.LEFT, padx=10)
schedule_btn = tk.Button(organise_btn_frame, text="Schedule Auto-Organise", command=schedule_organise)
schedule_btn.pack(side=tk.LEFT, padx=10)

# Hover buttons
hover_buttons = [theme_btn, choose_btn, howto_btn, preview_btn, select_all_btn, deselect_all_btn,
                 organise_selected_btn, organise_all_btn, reset_btn, schedule_btn]

# Status
status_label = tk.Label(window, text="", fg="#4CAF50", font=("Arial", 10, "italic"), bg="#f5f5f5")
status_label.pack(pady=5)
schedule_indicator = tk.Label(window, text="Scheduled auto-organise: Off", fg="#B0B0B0",
                              font=("Arial", 10, "italic"), bg="#f5f5f5")
schedule_indicator.pack(pady=2)

# Exit
exit_btn = tk.Button(window, text="Exit", command=window.quit)
exit_btn.pack(pady=10)
hover_buttons.append(exit_btn)

# Apply theme
apply_theme()

# Start schedule check loop
window.after(1000, check_schedule)

# Drag & Drop support
if DND_AVAILABLE:
    def drop(event):
        global target_directory
        for path in window.tk.splitlist(event.data):
            path = path.strip("{}")
            if os.path.isdir(path):
                target_directory = path
                load_items_list()
                status_label.config(text=f"Target directory: {target_directory}")
    window.drop_target_register(DND_FILES)
    window.dnd_bind('<<Drop>>', drop)

window.mainloop()


